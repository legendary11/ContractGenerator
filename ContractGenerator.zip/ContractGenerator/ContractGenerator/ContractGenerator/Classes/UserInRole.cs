using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContractGenerator
{
    public class UserInRole
    {
        User U = new User();
        Role R = new Role();
/*
        private int UserID = U.getUserID();
        private int RoleID = R.getRoleID();

        public int getUserID()
        {
            return UserID;
        }

        public int getRoleID()
        {
            return RoleID;
        }
 */
    }
}