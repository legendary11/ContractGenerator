using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContractGenerator
{
    public class Contract
    {  
        private ContractTemplate contractTemplate = new ContractTemplate();
        private User user;
        private int ContractID;
        private int TemplateID;
        private int UserID;
        private String PrimaryDomain;
        private String lastModifiedDate;
        private String CreatedBy;

        public int getContractID()
        {
            return ContractID;
        }
       
        public int getTemplateID()
        {
            return contractTemplate.getTemplateID();
        }

        public int getUserID()
        {
            return user.getUserID();
        }

        public String getPrimaryDomain()
        {
            return PrimaryDomain;
        }

        public String getCreatedDate()
        {
            return contractTemplate.getCreatedDate();
        }

        public String getLastModifiedDate()
        {
            return lastModifiedDate;
        }

        public String getCreatedBy()
        {
            return contractTemplate.getCreatedBy();
        }
        
    }
}