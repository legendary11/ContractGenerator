using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContractGenerator
{
    public class Contract
    {
        ContractTemplate CT = new ContractTemplate();
        User U = new User();

        private int ContractID;
       // private int TemplateID = CT.getTemplateID();
       // private int UserID = U.getUserID();
        private String PrimaryDomain;
       // private String CreateDate = CT.getCreateDate();
        private String ModifiedDate; //Is this the same as lastModified Date in ContractTemplate?
       // private String CreateBy = CT.getCreateBy();

        public int getContractID()
        {
            return ContractID;
        }
        /*
        public int getTemplateID()
        {
            return TemplateID;
        }

        public int getUserID()
        {
            return UserID;
        }

        public String getPrimaryDomain()
        {
            return PrimaryDomain;
        }

        public String getCreateDate()
        {
            return CreateDate;
        }

        public String getModifiedDate()
        {
            return ModifiedDate;
        }

        public String getCreateBy()
        {
            return CreateBy;
        }
        */
    }
}