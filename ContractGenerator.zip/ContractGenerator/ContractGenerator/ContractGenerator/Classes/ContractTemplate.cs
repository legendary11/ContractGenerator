using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContractGenerator
{
    public class ContractTemplate
    {
        private int TemplateID;
        private String TemplateTitle;
        private String CreatedDate;
        private String CreatedBy;
        private String LastModifiedDate;

        public int getTemplateID()
        {
            return TemplateID;
        }

        public String getTemplateTitle()
        {
            return TemplateTitle;
        }

        public String getCreatedDate()
        {
            return CreatedDate;
        }

        public String getCreatedBy()
        {
            return CreatedBy;
        }

        public String getLastModifiedDate()
        {
            return LastModifiedDate;
        }
    }
}