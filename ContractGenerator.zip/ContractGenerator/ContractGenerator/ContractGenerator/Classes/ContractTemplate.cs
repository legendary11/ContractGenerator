using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using iTextSharp.text.pdf;
using iTextSharp.text;


namespace ContractGenerator
{
    public class ContractTemplate
    {
        private int TemplateID;
        private String TemplateTitle;
        private String CreatedDate;
        private String CreatedBy;
        private String LastModifiedDate;

        public Document generateDocument()
        {
            Document doc = new Document();
            PdfWriter.GetInstance(doc, new FileStream("contract.pdf", FileMode.Create));
            doc.Open();
            doc.Close();
            return doc;
        }

        public void generateHeading(Document doc)
        {
            try
            {
                //add info to document
                //add heading table
                PdfWriter.GetInstance(doc, new FileStream("contract.pdf", FileMode.Append));
                doc.Open();
                PdfPTable table = new PdfPTable(2);
                table.AddCell("Company:");
                table.AddCell("Name:");
                table.AddCell("Address:");
                table.AddCell("City:");
                table.AddCell("Phone:");
                table.AddCell("Email:");

                doc.Add(table);
                doc.Close();
            }
            catch (Exception ex)
            {

            }
        }

        public int getTemplateID()
        {
            return TemplateID;
        }

        public String getTemplateTitle()
        {
            return TemplateTitle;
        }

        public String getCreatedDate()
        {
            return CreatedDate;
        }

        public String getCreatedBy()
        {
            return CreatedBy;
        }

        public String getLastModifiedDate()
        {
            return LastModifiedDate;
        }
    }
}