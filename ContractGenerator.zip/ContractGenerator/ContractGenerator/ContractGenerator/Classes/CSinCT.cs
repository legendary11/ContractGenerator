using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace ContractGenerator
{
    public class CSinCT
    {
        ContractTemplate CT = new ContractTemplate();
        ContractSection CS = new ContractSection();

       // private int TemplateID = CT.getTemplateID();
       // private int SectionID = CS.getSectionID();
        private String InitialBox;
        private bool OptOutBox;
        private String SignBox;
        private String EntryBox;

        /*
        public int getTemplateID()
        {
            return TemplateID;
        }

        public int getSectionID()
        {
            return SectionID;
        }
        */
        public String getInitialBox()
        {
            return InitialBox;
        }

        public bool getOptOutBox()
        {
            return OptOutBox;
        }

        public String getSignBox()
        {
            return SignBox;
        }

        public String getEntryBox()
        {
            return EntryBox;
        }
    }
}