using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace ContractGenerator
{
    public class CSinCT
    {
        private int TemplateID;
        private int SectionID;
        private String InitialBox;
        private bool OptOutBox;
        private String SignBox;
        private String EntryBox;
    }
       
}