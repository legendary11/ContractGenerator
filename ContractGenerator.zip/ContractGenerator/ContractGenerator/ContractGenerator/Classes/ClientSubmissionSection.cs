using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContractGenerator
{
    public class ClientSubmissionSection
    {
        private int SubmissionSectionID;
        private int SectionID;
        private int ContractID;
        private string OptOutInitial;
        private string ClientInitial;
        private ContractSection contractSection = new ContractSection();
        private Contract contract = new Contract();

        public int getSubmissionSectionID()
        {
            return SubmissionSectionID;
        }
        public int getSectionID()
        {
            return contractSection.getSectionID();
        }

        public int getContractID()
        {
            return contract.getContractID();
        }
        public String getOptOutInitial()
        {
            return OptOutInitial;
        }

        public String getClientInitial()
        {
            return ClientInitial;
        }
    }
}