using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContractGenerator
{
    public class ClientSubmissionSection
    {
        ContractSection CS = new ContractSection();
        Contract C = new Contract();

        private int SubmissionSectionID;
      //  private int SectionID = CS.getSectionID();
      //  private int ContractID = C.getContractID();
        private string OptOutInitial;
        private string ClientInitial;

        public int getSubmissionSectionID()
        {
            return SubmissionSectionID;
        }
        /*
        public int getSectionID()
        {
            return SectionID;
        }

        public int getContractID()
        {
            return ContractID;
        }
        */
        public String getOptOutInitial()
        {
            return OptOutInitial;
        }

        public String getClientInitial()
        {
            return ClientInitial;
        }
    }
}