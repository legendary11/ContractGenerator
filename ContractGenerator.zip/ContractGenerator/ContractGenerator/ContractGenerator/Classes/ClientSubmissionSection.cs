using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContractGenerator
{
    public class ClientSubmissionSection
    {
        private int SubmissionSectionID;
        private int SectionID;
        private int ContractID;
        private string OptOutInitial;
        private string ClientInitial;
    }
}