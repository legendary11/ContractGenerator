using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace ContractGenerator
{
    public class ClienSubmission
    {
        Contract C = new Contract();

        private int SubmissionID;
        private int ContractID;
        private String Sig; //"Signature" is a keyword
        private String SubmitDate;

        public int getSubmissionID()
        {
            return SubmissionID;
        }
        /*
        public int getContractID()
        {
            return C.getContractID;
        }
        */
        public String getSig()
        {
            return Sig;
        }

        public String getSubmitDate()
        {
            return SubmitDate;
        }
    }
}