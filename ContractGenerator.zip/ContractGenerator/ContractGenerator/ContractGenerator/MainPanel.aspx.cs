﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Configuration;


namespace ContractGenerator
{
    public partial class Default : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!User.Identity.IsAuthenticated)
            {
                viewContractsButton.Visible = false;
                viewProfieButton.Visible = false;
                createContractsButton.Visible = false;
                createEditButton.Visible = false;
                adminButton.Visible = false;
            }
        }

       
        protected void pdfButton_Click(object sender, EventArgs e)
        {
            ContractTemplate contract = new ContractTemplate();

            contract.generateDocument();
        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            Connect con = new Connect();
            con.executeSelectQuery("SELECT TemplateTitle, CreateDate, CreateBy, ModifiedDate FROM ContractTemplate");
        }
           
    }
}