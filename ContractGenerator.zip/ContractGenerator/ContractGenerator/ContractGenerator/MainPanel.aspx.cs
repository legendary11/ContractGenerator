﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Configuration;
using ContractGenerator.Classes;
using System.Windows.Forms;


namespace ContractGenerator
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!User.Identity.IsAuthenticated)
            {
                viewContractsButton.Visible = false;
                viewProfieButton.Visible = false;
                createEditButton.Visible = false;
                adminButton.Visible = false;
            }

        }
       
    }
}