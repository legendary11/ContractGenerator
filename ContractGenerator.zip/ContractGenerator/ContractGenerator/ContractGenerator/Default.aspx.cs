﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Configuration;
using System.IO.MemoryMappedFiles;


namespace ContractGenerator
{
    public partial class Default : System.Web.UI.Page
    {
        ConnectionStringSettings connectionStringSettings = ConfigurationManager.ConnectionStrings["ContractGenerator"];
        Document doc = new Document();

        protected void Page_Load(object sender, EventArgs e)
        {
            String connectionString = connectionStringSettings.ConnectionString;
            try
            {
                SqlConnection con = new SqlConnection(connectionString);

                con.Open();
                TextBox1.Text = "Connection open";
            }
            catch (Exception ex)
            {
                TextBox1.Text = "Connection not open";
            }
        }

        protected void pdfButton_Click(object sender, EventArgs e)
        {
            doc = new Document(PageSize.LETTER);
            //String path = "C:\\Users\\nmcc1_000\\contract.pdf";
            try
            {
               // PdfWriter.GetInstance(doc, new FileStream("contract.pdf", FileMode.Create));
                //add meta data
                doc.AddTitle("Contract Generator");
                doc.Open();
                //add info to document
                doc.Add(new Paragraph("first paragraph"));
                doc.Close();
                TextBox1.Text = "File Found";

            }
            catch (System.UnauthorizedAccessException ex)
            {
                TextBox1.Text = "File Error";
            }
        }
            protected void Generate_PDF(object sender, GridViewCommandEventArgs e)

            {
                // get the row index stored in the CommandArgument property
                int index = Convert.ToInt32(e.CommandArgument);

                // get the GridViewRow where the command is raised
                GridViewRow selectedRow = ((GridView)e.CommandSource).Rows[index];

                string msg = @"blah blah blah blah";

                using (MemoryMappedFile mmf = MemoryMappedFile.CreateNew("test1.pdf", 1000000))
                using (MemoryMappedViewStream stream = mmf.CreateViewStream())

                

                {
                    try
                    {
                        iTextSharp.text.Document d = new iTextSharp.text.Document(PageSize.A4, 72, 72, 172, 72);
                        PdfWriter.GetInstance(d, stream);

                        d.Open();
                        d.Add(new Paragraph("\n"));
                        d.Add(new Paragraph(msg));
                        d.Add(new Paragraph("\n"));
                        d.Add(new Paragraph(String.Format("Administrator")));
                        d.Close();

                        byte[] b;
                        BinaryReader rdr = new BinaryReader(stream);
                        b = new byte[mmf.CreateViewStream().Length];
                        rdr.Read(b, 0, (int)mmf.CreateViewStream().Length);


                        Response.Clear();
                        Response.ContentType = "Application/pdf";
                        Response.BinaryWrite(b);
                        Response.End();

                    }
                    catch (ArgumentException ex)
                    {
                        TextBox1.Text = "Error";
                    }
                    

                }

                

            }

                
                
          
    }
}